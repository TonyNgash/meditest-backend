<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;
use App\Models\Service;

class Booking extends Model
{
    use HasFactory;
    protected $table = "booking";
    protected $fillable = [
        'user_id',
        'self',
        'dependent_id',
        'service_id',
        'paid',
        'scheduled_date',
        'total_amount',
        'seen'
    ];
    /**
     * attributes that should be added by default
     *
     */
    protected $attributes = [
        'seen' => false
    ];

    /**
     * The attributes that has json type.
     *
     * @var array
     */
    protected $casts = [
        'service_id' => 'array','dependant_id' => 'array'
    ];

    /**
     * let the booking model know that it belongs to the user model
     */

    public function user(){
        return $this->hasMany(User::class);
    }




}
