<?php

namespace App\Http\Controllers;

use App\Http\Resources\PhleboResource;
use App\Models\BookedPatient;
use App\Models\BookedService;
use Illuminate\Http\Request;
use App\Models\Booking;
use App\Models\Dependant;
use App\Models\Phlebo;
use App\Models\Service;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class StaffController extends Controller
{
    /**
     * Call center wants to see all new bookings
     */
    public function getAllBookings(){
        $bookings = DB::table('booking')
        ->join('users','booking.user_id','=','users.id')
        ->select('booking.id', 'booking.total_amount', 'booking.scheduled_date', 'booking.scheduled_time', 'users.first_name', 'users.sirname')
        ->where('seen',0)
        ->get();

        return response()->json(['bookings'=>$bookings]);
    }
    public function getBookingDetails($id){//pass booking_id to this method
        //find the booker from the booking table given the booking id.
        $user_id = Booking::where('id',$id)->first()->user_id;//get the user_id from booking table. this is the user who made the booking.
        $booker = User::select('first_name','sirname','last_name','gender','email','phone','address')->where('id',$user_id)->get();
        //Find out if the booking is self or others
        $self = Booking::where('id',$id)->first()->self;//get the value of self where the given id matches.
        $patient_details=array();//array to store patient information.
        if($self){//if self is true, the user who created this booking is the patient
            //get user information from user table and store it in the array
            //$patient_details = $booker;//User::select('first_name','sirname','last_name','gender','address')->where('id',$user_id)->get();
            array_push($patient_details,User::select('first_name','sirname','last_name','gender')->where('id',$user_id)->get());
        }else{//if not, use booking_id to query booked_patients table to get dependant ids.
            $booked_patients = BookedPatient::where('booking_id',$id)->get();
            $patients = array();
            foreach($booked_patients as $booked_patient){
                //Get each dependant using dependant ids
                //array_push($patients,$booked_patient['dependant_id']);
                array_push($patients,Dependant::select('first_name','sirname','last_name','gender','address','relationship')->where('id',$booked_patient['dependant_id'])->get());
            }
            $patient_details = $patients;
        }
        //get service_ids from booked services table to use in getting the services from services table
        $booked_services = BookedService::where('booking_id',$id)->get();
        $services=[];
        foreach($booked_services as $booked_service){
            array_push($services,Service::where('id',$booked_service['service_id'])->get());
        }
        $stats = ['patients'=>count($patient_details),'services'=>count($services)];
        return response()->json(['booker'=>$booker,'patient'=>$patient_details,'services'=>$services,'stats'=>$stats]);
    }

    public function getAllUsers(){
        $users = User::all();
        return response()->json($users);
    }
    public function getAllPhlebos(){
        $phlebos = Phlebo::all();
        return PhleboResource::collection($phlebos);
    }

}
