<?php

namespace App\Http\Controllers;

use App\Http\Resources\DependantResource;
use App\Http\Resources\BookingResource;
use App\Mail\AccountCreatedMailer;
use App\Models\BookedPatient;
use App\Models\BookedService;
use App\Models\Dependant;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Booking;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\DB;
use App\Models\Service;

class UserController extends Controller
{

    public function addDependants(Request $request)
    {
        $rules = [
            'first_name'=>'required|min:2|max:20',
            'sirname'=>'required|min:2|max:20',
            'last_name'=>'required|min:2|max:20',
            'gender' => 'required|in:male,female',
            'address'=> 'required|min:4|max:50',
            'dob'=>'required|date_format:Y-m-d',
            'user_id'=>'required|numeric',
            'relationship' => 'required|in:child,spouse,parent,extended,sibling,other,'
        ];
        $validator = Validator::make($request->all(),$rules);
        if($validator->fails())
        {
            return response()->json(['status_code'=>400, 'message'=>$validator->errors()]);
        }
        $dependant = new Dependant();
        $dependant->first_name = $request->first_name;
        $dependant->sirname = $request->sirname;
        $dependant->last_name = $request->last_name;
        $dependant->gender = $request->gender;
        $dependant->address = $request->address;
        $dependant->dob = $request->dob;
        $dependant->user_id = $request->user_id;
        $dependant->relationship = $request->relationship;
        $res = $dependant->save();
        if($res){
            return response()->json(['status_code'=>200, 'message'=>'Dependent Created Successfuly']);
        }else{
            return response()->json(['status_code'=>400, 'message'=>"Something went wrong"]);
        }

    }
    public function updateDependant(Request $request, $id){
        $rules = [
            'first_name'=>'required|min:2|max:20',
            'sirname'=>'required|min:2|max:20',
            'last_name'=>'required|min:2|max:20',
            'gender' => 'required|in:male,female',
            'address'=> 'required|min:4|max:50',
            'dob'=>'required|date_format:Y-m-d',
            'relationship' => 'required|in:child,spouse,parent,extended,sibling,other,'
        ];
        $validator = Validator::make($request->all(),$rules);
        if($validator->fails())
        {
            return response()->json(['status_code'=>400, 'message'=>$validator->errors()]);
        }
        $dependant = Dependant::findOrFail($id);
        $dependant->first_name = $request->first_name;
        $dependant->sirname = $request->sirname;
        $dependant->last_name = $request->last_name;
        $dependant->gender = $request->gender;
        $dependant->address = $request->address;
        $dependant->dob = $request->dob;
        $dependant->relationship = $request->relationship;
        $res = $dependant->save();
        if($res){
            return response()->json(['status_code'=>200, 'message'=>'Dependent Updated Successfuly']);
        }else{
            return response()->json(['status_code'=>400, 'message'=>"Something went wrong"]);
        }
    }
    public function removeDependant($id){
        $dependant = Dependant::findOrFail($id);
        $res = $dependant->delete();
        if($res){
            return response()->json(['status_code'=>200, 'message'=>'Dependent Removed Successfuly']);
        }
    }

    public function getDependants($id){
        $dependants = Dependant::all()->where("user_id",$id);
        return DependantResource::collection($dependants);
    }


    public function makeBooking(Request $request){
        $rules = [
            'user_id'=>'required|numeric',
            'self'=>'boolean',
            'dependant_id' => 'array|required_if:self,false',
            'service_id'=>'required|array',
            'paid'=>'boolean',
            'scheduled_date'=>'nullable',
            'scheduled_time'=>'nullable',
            'total_amount'=>'required|numeric'
        ];
        $messages = '';
        $validator = Validator::make($request->all(),$rules);
        if($validator->fails())
        {
            return response()->json(['status_code'=>400, 'message'=>$validator->errors()]);
        }
        $booking = new Booking();
        $booking->user_id = $request->user_id;
        $booking->self = $request->self;
        $booking->paid = $request->paid;
        $booking->scheduled_date = $request->scheduled_date;
        $booking->scheduled_time = $request->scheduled_time;
        $booking->total_amount = $request->total_amount;
        $res = $booking->save();
        $booking_id = $booking->id;
        $self = $booking->self;
        if($res){
            //$messages .= ":Inserted into booking table:";
        }
        if($self){//is true
            //$messages .= ":Self is ".$self.":";
            //don't add to booked_patients as the patient is the user
        }else{//is false
            //add to booked_patients
            foreach($request->dependant_id as $dependant_id){
                $booked_patient = new BookedPatient();
                $booked_patient->booking_id = $booking_id;
                $booked_patient->dependant_id = $dependant_id;
                $booked_patient->save();
                //$messages .= ":Inserted into booked_patient table:";
            }
            //$messages .= ":Self is ".$self.":";
        }

        foreach($request->service_id as $service_id){
            $booked_service = new BookedService();
            $booked_service->booking_id = $booking_id;
            $booked_service->service_id = $service_id;
            $booked_service->save();
            //$messages .= ":Inserted into booked_services:";
        }
        $messages="Booking Succesfully Created";
        return response()->json(['status_code'=>200, 'message'=>$messages]);
    }
    /**
     * name: viewBooking($id)
     * desc: we want the user to be able to view bookings they've made.
     */
    public function viewBooking($id)
    {//user_id is beign passed to this method through url

        //find all new bookings where user_id and age match the given ones.
        $bookings = Booking::select('id','self','paid','total_amount','created_at')->where('user_id',$id)->where('age',1)->get();

        //find all patients
        $counter = 0;
        $no_of_patients = [];//create somewhere to store the number of patients
        $no_of_services = [];
        foreach($bookings as $booking)//we loop through the bookings result
        {
            if($booking['self']){//if self is true,
                array_push($no_of_patients,1);//the number of patients is automatically one.
                $counter ++;
            }else{//if not, fetch for booked_patients with booking_id.
                $patients = BookedPatient::where('booking_id',$booking['id'])->get();
                array_push($no_of_patients,count($patients));
                $counter ++;
            }
            //using booking_id fetch booked_services table
            $services = BookedService::where('booking_id',$booking['id'])->get();
            array_push($no_of_services,count($services));

        }


        //find all services
        return response()->json(['data'=>$bookings]);

    }
    public function viewBookingDetails($id){//receives booking_id
        //query the db
        //find the booker
        $user_id = Booking::where('id',$id)->first()->user_id;//get the user_id from booking table
        $booker = User::select('first_name','sirname','last_name','gender','email','phone','address')->where('id',$user_id)->get();
        //Find out if the booking is self or others
        $self = Booking::where('id',$id)->first()->self;//get the value of self where the given id matches.
        $patient_details=[];//#3. array to store patient information.
        if($self){//if self is true, the user who created this booking is the patient
            //get user information from user table and store it in the array
            //$patient_details = $booker;//User::select('first_name','sirname','last_name','gender','address')->where('id',$user_id)->get();
            array_push($patient_details,$booker);
        }else{//if not, use booking_id to query booked_patients table to get dependant ids.
            $booked_patients = BookedPatient::where('booking_id',$id)->get();
            $patients = array();
            foreach($booked_patients as $booked_patient){
                //Get each dependant using dependant ids
                //array_push($patients,$booked_patient['dependant_id']);
                array_push($patients,Dependant::select('first_name','sirname','last_name','gender','address')->where('id',$booked_patient['dependant_id'])->get());
            }
            $patient_details = $patients;
        }
        //get service_ids from booked services table to use in getting the services from services table
        $booked_services = BookedService::where('booking_id',$id)->get();
        $services=[];
        foreach($booked_services as $booked_service){
            array_push($services,Service::where('id',$booked_service['service_id'])->get());
        }
        $stats = ['patients'=>count($patient_details),'services'=>count($services)];
        return response()->json(['booker'=>$booker,'patient'=>$patient_details,'services'=>$services,'stats'=>$stats]);

    }

    public function findFreeBookingSlot(){
        //check scheduled dates
        //return all free slots of particular day
        return response()->json(['status_code'=>200, 'message'=>'Free Time Slots coming soon']);
    }

    public function makePayment(){

        //with user_id,amount,payment_method,booking_id
        //make payment gateway transaction
        //add record to accounts table

        return response()->json(['status_code'=>200, 'message'=>'make payments coming soon']);
    }
}
