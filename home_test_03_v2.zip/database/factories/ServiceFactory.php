<?php

namespace Database\Factories;

use App\Models\Service;
use Illuminate\Database\Eloquent\Factories\Factory;

class ServiceFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Service::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'test_code'=>'MDS0351',
            'test_name'=>'ALKALINE PHOSPHATASE,SERUM',
            'test_price'=>700.00,
            'test_constituents'=>'ALKALINE PHOSPHATASE, SERUM',
            'test_category_id'=>'3',
            'test_category'=>'HEPATITIS & GI DISORDERS',
            'test_prerequisites'=>'12 hours fasting is recommended',
            'test_report_availability'=>'Same Day',
            'test_desc'=>'Diagnosis and monitoring treatment of liver, bone, intestinal, and parathyroid diseases',
            'home' => true,
            'creator_job_id'=>'5',
            'status'=>'active',
            'image_path'=>$this->faker->imageUrl($width = 640, $height = 480,'cat',true)
        ];
    }
}
