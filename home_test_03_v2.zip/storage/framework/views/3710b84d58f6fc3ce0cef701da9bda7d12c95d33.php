<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Welcome To MEDITEST Diagnostics Services</h1>
    <p>We are pleased to inform you that you have created an account from the mobile application.</p>
    <br>
    <br>
    <br>
    <h3>Your Details Are As Follows</h3>
    <ul>
        <li>First Name: <?php echo e($details['first_name']); ?></li>
        <li>Sirname: <?php echo e($details['sirname']); ?></li>
        <li>Last Name: <?php echo e($details['last_name']); ?></li>
        <li>Gender: <?php echo e($details['gender']); ?></li>
        <li>Email: <?php echo e($details['email']); ?></li>
        <li>Phone: <?php echo e($details['phone']); ?></li>
        <li>Address: <?php echo e($details['address']); ?></li>
        <li>Date Of Birth: <?php echo e($details['dob']); ?></li>
    </ul>
    <br>
    <br>
    <br>
    <h3>Please Verify Your Account By Clicking Link Below</h3>

</body>
</html>
<?php /**PATH F:\projos\MEDITEST\2\home_test\resources\views\email\account_created.blade.php ENDPATH**/ ?>