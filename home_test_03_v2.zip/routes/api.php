<?php

use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\StaffController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});


Route::group(['prefix'=>'v1'], function(){

    //general unauthenticated routes here

    Route::group(['prefix'=>'user'],function(){
        //unauthenticated routes for users here

        //get all services available
        Route::get('/services',[ServiceController::class,'index']);

        //get one service with given Id
        Route::get('/services/{id}',[ServiceController::class,'show']);

        //register a user
        Route::post('/register',[RegisterController::class,'registerUser']);

        //send user account creation confirmation email
        //Route::post('user-account-created-email',[UserController::class,'userAccountCreatedEmail']);

        //log a user in
        Route::post('/login',[LoginController::class,'loginUser']);

        //Forgot Password?
        //Route to send the password reset also takes the email
        Route::post('/forgot-password',[UserController::class,'forgotPassword']);

        //Route to validate the reset code
        Route::post('/reset-password-token',[UserController::class,'resetPassword']);

        //Route to take in the new password
        Route::post('/new-password',[UserController::class,'setNewPassword']);

        Route::group(['middleware'=>['auth:sanctum']],function(){
            //authenticated routes for users here

            //user add dependants
            Route::post('/add-dependant',[UserController::class,'addDependants']);

            //user view their own dependants
            Route::post('/dependants/{id}',[UserController::class,'getDependants']);

            //user update dependant
            Route::post('/update-dependant/{id}',[UserController::class,'updateDependant']);

            //user remove dependants
            Route::post('/remove-dependant/{id}',[UserController::class,'removeDependant']);

            //user make booking
            Route::post('/book',[UserController::class,'makeBooking']);

            //user view their own bookings - pass user_id
            Route::get('/bookings/{id}',[UserController::class,'viewBooking']);

            //user view individual booking details - pass booking_id
            Route::get('/booking/{id}',[UserController::class,'viewBookingDetails']);

            //user view their history of past bookings
            Route::get('/booking-history',[UserController::class,'viewBookingHistory']);

            //user view individual booking history details - pass booking_history_id
            Route::get('/booking-history/{id}',[UserController::class,'viewBookingHistoryDetails']);

            //user make payment
            Route::post('/payment',[UserController::class,'makePayment']);

            //user logout
            Route::post('/logout',[LoginController::class,'logoutUser']);
        });
    });
    //User routes end here*****************************************
    Route::group(['prefix'=>'staff'],function(){
        //Unauthenticated routes for staff here

        //Get a list of all users
        Route::get('/users',[StaffController::class,'getAllUsers']);

        //Get a list of all bookings
        Route::get('/bookings',[StaffController::class,'getAllBookings']);

        //Get details of a specific booking
        Route::get('/bookings/{id}',[StaffController::class,'getBookingDetails']);

        //Get a list of all services
        Route::get('/services',[ServiceController::class,'getAllServices']);

        //Add new services
        //Route::post('/add-service',[ServiceController::class,'store']);

        //Route::put('/services/{id}',[ServiceController::class,'update']);
        //Route::delete('/services/{id}',[ServiceController::class,'destroy']);

        //Get a list of all phlebos
        Route::get('/phlebos',[StaffController::class,'getAllPhlebos']);



    });



});
